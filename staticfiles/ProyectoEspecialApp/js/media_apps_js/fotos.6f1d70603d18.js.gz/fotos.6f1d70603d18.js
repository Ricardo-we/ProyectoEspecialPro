var imagenG = document.querySelector('.imgcontainer');



imagenG.addEventListener('click', function(){
    imagenG.classList.toggle('imgBig');
});
document.getElementById('imgVar2').addEventListener('click',function(){
    document.getElementById('imgVar2').classList.toggle('imgBig');
});
document.getElementById('imgVar3').addEventListener('click',function(){
    document.getElementById('imgVar3').classList.toggle('imgBig');
});